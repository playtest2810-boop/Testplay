# Sample Tableau Project

Files included:
- sales_data.csv
- sample_dashboard.twb

You can open the CSV in Tableau and build dashboards/charts.
